const app = require('./express-server')
const port = 4000

app.listen(port)
console.log(`listening on http://localhost:${port}`)
